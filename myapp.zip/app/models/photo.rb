class Photo < ApplicationRecord
end
